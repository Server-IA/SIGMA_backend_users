from __future__ import annotations

import os
import json
import logging
import uuid
from typing import Any, Optional, Dict

try:
    # FastAPI request type hint (opcional, no rompe si no está)
    from fastapi import Request as FastAPIRequest  # type: ignore
except Exception:  # pragma: no cover
    FastAPIRequest = None  # type: ignore

from . import emit_audit  # emit_audit ya existente en el SDK

logger = logging.getLogger(__name__)

SERVICE_NAME = os.getenv("SERVICE_NAME", "unknown")
MAX_LEN = 32_000
REDACT_KEYS = {"password", "secret", "token", "api_key", "authorization", "auth", "private_key"}


def _redact(value: Any) -> Any:
    try:
        if isinstance(value, dict):
            out = {}
            for k, v in value.items():
                if str(k).lower() in REDACT_KEYS:
                    out[k] = "***REDACTED***"
                else:
                    out[k] = _redact(v)
            return out
        if isinstance(value, list):
            return [_redact(v) for v in value]
        return value
    except Exception:
        return "***REDACTED***"


def _trim_jsonable(obj: Any) -> Any:
    def _trim(o):
        if isinstance(o, str) and len(o) > MAX_LEN:
            return o[:MAX_LEN] + "…<trimmed>"
        if isinstance(o, dict):
            return {k: _trim(v) for k, v in o.items()}
        if isinstance(o, list):
            return [_trim(v) for v in o]
        return o

    try:
        json.dumps(obj)
        return _trim(obj)
    except Exception:
        try:
            return json.loads(json.dumps(obj, default=str))
        except Exception:
            return str(obj)[:MAX_LEN] + "…<trimmed>"


def _extract_ctx(request: Any) -> tuple[Optional[str], Optional[str], Optional[str]]:
    """
    Devuelve (request_id, ip, user_agent) desde:
    - FastAPI: request.state / headers
    - Django: request.META
    """
    if request is None:
        return None, None, None

    # --- FastAPI ---
    state = getattr(request, "state", None)
    headers = getattr(request, "headers", None)
    client = getattr(request, "client", None)

    if state or headers:
        req_id = getattr(state, "request_id", None)
        if not req_id and headers:
            req_id = headers.get("x-request-id")
        if not req_id:
            req_id = str(uuid.uuid4())

        ip = getattr(state, "ip", None)
        if not ip and headers:
            xff = headers.get("x-forwarded-for")
            if xff:
                ip = xff.split(",")[0].strip()
        if not ip and client:
            ip = getattr(client, "host", None)

        ua = getattr(state, "user_agent", None)
        if not ua and headers:
            ua = headers.get("user-agent")

        if req_id or ip or ua:
            return req_id, ip, ua

    # --- Django ---
    META = getattr(request, "META", None)
    if isinstance(META, dict):
        req_id = META.get("HTTP_X_REQUEST_ID") or str(uuid.uuid4())
        xff = META.get("HTTP_X_FORWARDED_FOR")
        ip = (xff.split(",")[0].strip() if xff else None) or META.get("REMOTE_ADDR")
        ua = META.get("HTTP_USER_AGENT")
        return req_id, ip, ua

    return None, None, None

# Reserved parameters
RESERVED_META = {
    "service", "module", "submodule", "feature",
    "object_type", "object_id", "operation",
    "before", "after", "request_id", "ip", "user_agent",
    "actor_id", "actor_role", "actor_type", "ts", "event_id"
}

class AuditClient:
    """Cliente SDK para emitir eventos de auditoría desde FastAPI o Django."""

    def __init__(self, request: Any = None, service_name: Optional[str] = None):
        self.request = request
        self.service_name = service_name or SERVICE_NAME

    def emit(
        self,
        *,
        operation: str,
        module: str,
        object_type: Optional[str] = None,
        object_id: Optional[str] = None,
        submodule: Optional[str] = None,  
        feature: Optional[str] = None, 
        actor_id: Optional[str] = None,
        actor_role: Optional[str] = None,
        before: Optional[Dict[str, Any]] = None,
        after: Optional[Dict[str, Any]] = None,
        meta: Optional[Dict[str, Any]] = None,
    ) -> None:
        try:
            # limpia meta de claves reservadas
            clean_meta = None
            if meta is not None:
                clean_meta = {k: v for k, v in meta.items() if k not in RESERVED_META}
                clean_meta = _trim_jsonable(_redact(clean_meta))

            request_id, ip, user_agent = _extract_ctx(self.request)
            payload = {
                "service": self.service_name,
                "operation": operation,
                "module": module,
                "submodule": submodule,     
                "feature": feature,         
                "object_type": object_type,
                "object_id": object_id,
                "actor_id": actor_id,
                "actor_role": actor_role,
                "actor_type": "user" if actor_id else "service",
                "before": _trim_jsonable(_redact(before)) if before is not None else None,
                "after": _trim_jsonable(_redact(after)) if after is not None else None,
                "request_id": request_id,
                "ip": ip,
                "user_agent": user_agent,
                "meta": clean_meta,
            }
            emit_audit(payload)
        except Exception as e:
            logger.warning("Audit emit failed (%s/%s id=%s): %s", module, operation, object_id, e)

    # Atajos semánticos
    def create(
        self,
        *,
        module: str,
        object_type: str,
        object_id: str,
        after: Dict[str, Any],                      
        actor_id: Optional[str] = None,
        meta: Optional[Dict[str, Any]] = None,
        submodule: Optional[str] = None,
        feature: Optional[str] = None,
        actor_role: Optional[str] = None,
    ) -> None:
        self.emit(
            operation="CREATE",
            module=module,
            object_type=object_type,
            object_id=object_id,
            actor_id=actor_id,
            actor_role=actor_role,
            after=after,
            meta=meta,
            submodule=submodule,
            feature=feature,
        )


    def update(
        self,
        *,
        module: str,
        object_type: str,
        object_id: str,
        before: Dict[str, Any],                     
        after: Dict[str, Any],
        actor_id: Optional[str] = None,
        meta: Optional[Dict[str, Any]] = None,
        submodule: Optional[str] = None,
        feature: Optional[str] = None,
        actor_role: Optional[str] = None,
    ) -> None:
        self.emit(
            operation="UPDATE",
            module=module,
            object_type=object_type,
            object_id=object_id,
            actor_id=actor_id,
            actor_role=actor_role,
            before=before,
            after=after,
            meta=meta,
            submodule=submodule,
            feature=feature,
            
        )


    def delete(
        self,
        *,
        module: str,
        object_type: str,
        object_id: str,
        before: Dict[str, Any],                  
        actor_id: Optional[str] = None,
        meta: Optional[Dict[str, Any]] = None,
        submodule: Optional[str] = None,
        feature: Optional[str] = None,
        actor_role: Optional[str] = None,
    ) -> None:
        self.emit(
            operation="DELETE",
            module=module,
            object_type=object_type,
            object_id=object_id,
            actor_id=actor_id,
            actor_role=actor_role,
            before=before,
            meta=meta,
            submodule=submodule,
            feature=feature,
        )