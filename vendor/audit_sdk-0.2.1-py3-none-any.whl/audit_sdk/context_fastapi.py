import uuid
from starlette.middleware.base import BaseHTTPMiddleware

class AuditContextMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        request.state.request_id = str(uuid.uuid4())
        request.state.ip = request.client.host if request.client else None
        request.state.user_agent = request.headers.get("user-agent")
        return await call_next(request)