import os
import uuid
import logging
import datetime
from typing import Dict, Any, Optional, Mapping, Tuple

import requests

log = logging.getLogger("audit_sdk")

# Config por entorno
AUDIT_URL = os.getenv("AUDIT_URL", "http://localhost:8070/audit-events")
AUDIT_TOKEN = os.getenv("AUDIT_TOKEN", "devtoken")
TIMEOUT = float(os.getenv("AUDIT_HTTP_TIMEOUT", "1.5"))

# Campos permitidos por el esquema 
_ALLOWED_FIELDS = {
    "event_id",
    "ts",
    "actor_id",
    "actor_name",
    "actor_role",
    "permission_id",
    "permission_description",
    "operation",
    "object_id",
    "ip",
    "user_agent",
    "diff",
    "meta",
}

def _utc_now_iso() -> str:
    # ISO8601 sin microsegundos + 'Z' (UTC)
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

def compute_diff(before: Optional[Mapping[str, Any]],
                 after: Optional[Mapping[str, Any]]) -> Dict[str, Any]:
    """
    Genera diff convencional (changed/removed).
    NOTA: create() usa 'created' para claridad.
    """
    b = dict(before or {})
    a = dict(after or {})

    changed: Dict[str, Dict[str, Any]] = {}
    removed: Dict[str, Any] = {}

    keys = set(b.keys()) | set(a.keys())
    for k in keys:
        b_has, a_has = k in b, k in a
        if b_has and a_has:
            if b[k] != a[k]:
                changed[k] = {"from": b[k], "to": a[k]}
        elif b_has and not a_has:
            removed[k] = b[k]
        else:
            # new field
            changed[k] = {"from": None, "to": a[k]}
    return {"changed": changed, "removed": removed}

def _shape(event: Dict[str, Any]) -> Dict[str, Any]:
    ev = dict(event)
    ev.setdefault("event_id", str(uuid.uuid4()))
    ev.setdefault("ts", _utc_now_iso())
    ev.setdefault("diff", {"created": {}, "changed": {}, "removed": {}})
    ev.setdefault("meta", {})

    shaped = {k: v for k, v in ev.items() if k in _ALLOWED_FIELDS}

    # Requeridos mínimos
    required = ["actor_id", "actor_name", "actor_role", "operation"]
    missing = [r for r in required if not shaped.get(r)]
    if missing:
        raise ValueError(f"Campos requeridos faltantes: {missing}")

    shaped["operation"] = str(shaped["operation"]).upper()

    # Normalizar diff
    d = shaped.get("diff") or {}
    if not isinstance(d, dict):
        raise ValueError("diff inválido: se espera un objeto.")
    d.setdefault("created", {})
    d.setdefault("changed", {})
    d.setdefault("removed", {})
    if not isinstance(d["created"], dict) or not isinstance(d["changed"], dict) or not isinstance(d["removed"], dict):
        raise ValueError("diff inválido: keys 'created','changed','removed' deben ser objetos (dict).")
    shaped["diff"] = d

    # Normalizar meta (debe ser objeto JSONB)
    m = shaped.get("meta") or {}
    if not isinstance(m, dict):
        raise ValueError("meta inválido: se espera un objeto (dict).")
    shaped["meta"] = m

    return shaped

def _extract_ctx(request: Any) -> Tuple[Optional[str], Optional[str]]:
    """Extrae ip y user_agent de FastAPI/Django request si se pasa."""
    if request is None:
        return None, None

    # FastAPI
    try:
        headers = getattr(request, "headers", None)
        client = getattr(request, "client", None)
        ip = None
        if headers:
            xff = headers.get("x-forwarded-for")
            if xff:
                ip = xff.split(",")[0].strip()
        if not ip and client:
            ip = getattr(client, "host", None)
        ua = headers.get("user-agent") if headers else None
        if ip or ua:
            return ip, ua
    except Exception:
        pass

    # Django
    try:
        META = getattr(request, "META", None)
        if isinstance(META, dict):
            xff = META.get("HTTP_X_FORWARDED_FOR")
            ip = (xff.split(",")[0].strip() if xff else None) or META.get("REMOTE_ADDR")
            ua = META.get("HTTP_USER_AGENT")
            return ip, ua
    except Exception:
        pass

    return None, None

class AuditClient:
    """
    Cliente:
      - Toma AUDIT_URL/AUDIT_TOKEN/TIMEOUT de entorno si no se pasan.
      - request opcional para extraer ip/user-agent.
      - Compatible con create/update/delete/emit.
    """

    def __init__(
        self,
        request: Any = None,
        base_url: Optional[str] = None,
        token: Optional[str] = None,
        timeout: Optional[float] = None,
        session: Optional[requests.Session] = None,
    ):
        self.base_url = (base_url or AUDIT_URL).rstrip("/")
        self.token = token or AUDIT_TOKEN
        self.timeout = timeout if timeout is not None else TIMEOUT
        self._session = session or requests.Session()
        self._request = request

    # Emisor genérico 
    def emit(self, event: Dict[str, Any]) -> Tuple[bool, Optional[int], Optional[str]]:
        try:
            payload = _shape(event)
        except Exception as e:
            log.warning("audit shape failed: %s; event=%s", e, event)
            return False, None, str(e)

        try:
            r = self._session.post(
                self.base_url,
                json=payload,
                headers={"X-Audit-Token": self.token},
                timeout=self.timeout,
            )
            ok = 200 <= r.status_code < 300
            if not ok:
                log.warning("audit emit failed: %s %s", r.status_code, r.text)
            return ok, r.status_code, (None if ok else r.text)
        except Exception as e:
            log.warning("audit http failed: %s", e)
            return False, None, str(e)

    # Helper 
    def _send_minimal(
        self,
        *,
        operation: str,
        actor_id: str,
        actor_name: str,
        actor_role: str,
        object_id: Optional[str],
        diff: Dict[str, Any],
        permission_id: Optional[int] = None,
        permission_description: Optional[str] = None,
        meta: Optional[Dict[str, Any]] = None,
    ) -> Tuple[bool, Optional[int], Optional[str]]:
        ip, ua = _extract_ctx(self._request)
        payload: Dict[str, Any] = {
            "operation": operation,
            "actor_id": actor_id,
            "actor_name": actor_name,
            "actor_role": actor_role,
            "object_id": object_id,
            "permission_id": permission_id,
            "ip": ip,
            "user_agent": ua,
            "diff": diff or {"created": {}, "changed": {}, "removed": {}},
            "meta": meta or {},
        }
        if permission_description:
            payload["permission_description"] = permission_description
        return self.emit(payload)

    # Wrappers compatibles
    def create(
        self,
        *,
        object_id: Optional[str] = None,
        after: Optional[Dict[str, Any]] = None,
        actor_id: Optional[str] = None,
        actor_name: Optional[str] = None,
        actor_role: Optional[str] = None,
        meta: Optional[Dict[str, Any]] = None,
        permission_id: Optional[Any] = None,
        permission_description: Optional[str] = None,
        lean: bool = False,
    ) -> Tuple[bool, Optional[int], Optional[str]]:
        # Para creación hacemos diff con 'created' por claridad
        created = dict(after or {})
        diff = {"created": created, "changed": {}, "removed": {}}
        return self._send_minimal(
            operation="CREATE",
            actor_id=actor_id or "",
            actor_name=actor_name or "",
            actor_role=actor_role or "",
            object_id=str(object_id) if object_id is not None else None,
            diff=diff,
            permission_id=int(permission_id) if isinstance(permission_id, (str, int)) and str(permission_id).isdigit() else permission_id,  # type: ignore
            permission_description=permission_description,
            meta=meta,
        )

    def update(
        self,
        *,
        object_id: Optional[str] = None,
        before: Optional[Dict[str, Any]] = None,
        after: Optional[Dict[str, Any]] = None,
        actor_id: Optional[str] = None,
        actor_name: Optional[str] = None,
        actor_role: Optional[str] = None,
        meta: Optional[Dict[str, Any]] = None,
        permission_id: Optional[Any] = None,
        permission_description: Optional[str] = None,
        lean: bool = False,
    ) -> Tuple[bool, Optional[int], Optional[str]]:
        diff = compute_diff(before or {}, after or {})
        return self._send_minimal(
            operation="UPDATE",
            actor_id=actor_id or "",
            actor_name=actor_name or "",
            actor_role=actor_role or "",
            object_id=str(object_id) if object_id is not None else None,
            diff=diff,
            permission_id=int(permission_id) if isinstance(permission_id, (str, int)) and str(permission_id).isdigit() else permission_id,  # type: ignore
            permission_description=permission_description,
            meta=meta,
        )

    def delete(
        self,
        *,
        object_id: Optional[str] = None,
        before: Optional[Dict[str, Any]] = None,
        actor_id: Optional[str] = None,
        actor_name: Optional[str] = None,
        actor_role: Optional[str] = None,
        meta: Optional[Dict[str, Any]] = None,
        permission_id: Optional[Any] = None,
        permission_description: Optional[str] = None,
        lean: bool = False,
    ) -> Tuple[bool, Optional[int], Optional[str]]:
        diff = {"created": {}, "changed": {}, "removed": dict(before or {})}
        return self._send_minimal(
            operation="DELETE",
            actor_id=actor_id or "",
            actor_name=actor_name or "",
            actor_role=actor_role or "",
            object_id=str(object_id) if object_id is not None else None,
            diff=diff,
            permission_id=int(permission_id) if isinstance(permission_id, (str, int)) and str(permission_id).isdigit() else permission_id,  # type: ignore
            permission_description=permission_description,
            meta=meta,
        )