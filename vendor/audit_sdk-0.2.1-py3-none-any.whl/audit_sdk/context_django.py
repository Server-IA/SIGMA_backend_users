import threading, uuid
local = threading.local()

class AuditContextMiddleware:
    def __init__(self, get_response): self.get_response = get_response
    def __call__(self, request):
        local.request_id = str(uuid.uuid4())
        local.ip = request.META.get("REMOTE_ADDR")
        local.user_agent = request.META.get("HTTP_USER_AGENT")
        resp = self.get_response(request)
        local.request_id = local.ip = local.user_agent = None
        return resp