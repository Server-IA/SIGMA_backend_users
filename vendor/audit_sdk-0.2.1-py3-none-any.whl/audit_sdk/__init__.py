import os
import logging
from typing import Dict, Any, Optional

from .client import AuditClient, compute_diff  

log = logging.getLogger("audit_sdk")

AUDIT_URL   = os.getenv("AUDIT_URL", "http://localhost:8070/audit-events")
AUDIT_TOKEN = os.getenv("AUDIT_TOKEN", "devtoken")
TIMEOUT     = float(os.getenv("AUDIT_HTTP_TIMEOUT", "1.5"))

def emit_audit(event: Dict[str, Any], *, url: Optional[str] = None) -> None:
    """
    Helper de compatibilidad:
    - Acepta un dict con los campos válidos del esquema actual (v2).
    - Envía a /audit-events usando AUDIT_TOKEN.
    - Si falla, NO rompe el flujo de negocio.
    """
    try:
        client = AuditClient(
            base_url=url or AUDIT_URL,
            token=AUDIT_TOKEN,
            timeout=TIMEOUT,
        )
        client.emit(event)
    except Exception as e:
        log.warning("emit_audit failed: %s", e)

__all__ = ["emit_audit", "AuditClient", "compute_diff"]