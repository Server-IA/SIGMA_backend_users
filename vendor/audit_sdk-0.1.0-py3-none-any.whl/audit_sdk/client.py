# audit_sdk/client.py
from __future__ import annotations

import os
import json
import logging
import uuid
from typing import Any, Optional, Dict, Tuple

try:
    from fastapi import Request as FastAPIRequest  # type: ignore
except Exception:  # pragma: no cover
    FastAPIRequest = None  # type: ignore

from . import emit_audit  # type: ignore

logger = logging.getLogger(__name__)

# Config básica (SERVICE_NAME ya no se envía, pero se mantiene por compatibilidad)
SERVICE_NAME = os.getenv("SERVICE_NAME", "unknown")
MAX_LEN = 32_000
REDACT_KEYS = {"password", "secret", "token", "api_key", "authorization", "auth", "private_key"}

# Claves de meta que no deben sobreescribir top-level
RESERVED_META = {
    # "service",                 # ← ya no se usa
    "module", "submodule", "feature",
    "object_type", "object_id", "operation",
    "before", "after", "request_id", "ip", "user_agent",
    "actor_id", "actor_role",
    # "actor_type",              # ← ya no se usa
    "ts", "event_id",
    "permission_id", "diff"
}

# ------------- utilidades -------------
def _redact(value: Any) -> Any:
    try:
        if isinstance(value, dict):
            out = {}
            for k, v in value.items():
                out[k] = "***REDACTED***" if str(k).lower() in REDACT_KEYS else _redact(v)
            return out
        if isinstance(value, list):
            return [_redact(v) for v in value]
        return value
    except Exception:
        return "***REDACTED***"

def _trim_jsonable(obj: Any) -> Any:
    def _trim(o: Any) -> Any:
        if isinstance(o, str) and len(o) > MAX_LEN:
            return o[:MAX_LEN] + "…<trimmed>"
        if isinstance(o, dict):
            return {k: _trim(v) for k, v in o.items()}
        if isinstance(o, list):
            return [_trim(v) for v in o]
        return o
    try:
        json.dumps(obj)
        return _trim(obj)
    except Exception:
        try:
            return json.loads(json.dumps(obj, default=str))
        except Exception:
            return str(obj)[:MAX_LEN] + "…<trimmed>"

def _extract_ctx(request: Any) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    if request is None:
        return None, None, None
    state = getattr(request, "state", None)
    headers = getattr(request, "headers", None)
    client = getattr(request, "client", None)
    if state or headers:
        req_id = getattr(state, "request_id", None)
        if not req_id and headers:
            req_id = headers.get("x-request-id")
        if not req_id:
            req_id = str(uuid.uuid4())
        ip = getattr(state, "ip", None)
        if not ip and headers:
            xff = headers.get("x-forwarded-for")
            if xff:
                ip = xff.split(",")[0].strip()
        if not ip and client:
            ip = getattr(client, "host", None)
        ua = getattr(state, "user_agent", None)
        if not ua and headers:
            ua = headers.get("user-agent")
        if req_id or ip or ua:
            return req_id, ip, ua
    META = getattr(request, "META", None)
    if isinstance(META, dict):
        req_id = META.get("HTTP_X_REQUEST_ID") or str(uuid.uuid4())
        xff = META.get("HTTP_X_FORWARDED_FOR")
        ip = (xff.split(",")[0].strip() if xff else None) or META.get("REMOTE_ADDR")
        ua = META.get("HTTP_USER_AGENT")
        return req_id, ip, ua
    return None, None, None

# ------------- diff sin 'added' -------------
def _compute_diff(before: Any, after: Any) -> Dict[str, Any]:
    """
    Devuelve un diff con forma:
    { "removed": {k: v}, "changed": {k: {"from": x, "to": y} | subdiff} }
    - Adiciones: se representan como changed[k] = {"from": None, "to": v}
    - Eliminaciones: van en removed
    """
    try:
        if not isinstance(before, dict) or not isinstance(after, dict):
            if before == after:
                return {"removed": {}, "changed": {}}
            if before is None and after is not None:
                return {"removed": {}, "changed": {"__value__": {"from": None, "to": after}}}
            if after is None and before is not None:
                return {"removed": {"__value__": before}, "changed": {}}
            return {"removed": {}, "changed": {"__value__": {"from": before, "to": after}}}

        b_keys = set(before.keys())
        a_keys = set(after.keys())

        removed = {k: before[k] for k in (b_keys - a_keys)}

        changed: Dict[str, Any] = {}
        # comunes
        for k in (b_keys & a_keys):
            b_v, a_v = before[k], after[k]
            if isinstance(b_v, dict) and isinstance(a_v, dict):
                sub = _compute_diff(b_v, a_v)
                if sub["removed"] or sub["changed"]:
                    changed[k] = sub
            else:
                if b_v != a_v:
                    changed[k] = {"from": b_v, "to": a_v}
        # adiciones
        for k in (a_keys - b_keys):
            changed[k] = {"from": None, "to": after[k]}

        return {"removed": removed, "changed": changed}
    except Exception:
        return {"removed": {}, "changed": {"__error__": "diff_failed"}}

# ------------- cliente -------------
class AuditClient:
    """Cliente SDK para emitir eventos de auditoría desde FastAPI o Django."""

    def __init__(self, request: Any = None, service_name: Optional[str] = None):
        self.request = request
        self.service_name = service_name or SERVICE_NAME  # ya no se envía en payload

    def emit(
        self,
        *,
        operation: str,
        module: str,
        object_type: Optional[str] = None,
        object_id: Optional[str] = None,
        submodule: Optional[str] = None,
        feature: Optional[str] = None,
        actor_id: Optional[str] = None,
        actor_role: Optional[str] = None,
        before: Optional[Dict[str, Any]] = None,
        after: Optional[Dict[str, Any]] = None,
        meta: Optional[Dict[str, Any]] = None,
        permission_id: Optional[str] = None,
        diff: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Emite un evento de auditoría:
        - No envía 'service' ni 'actor_type'
        - 'diff' solo {removed, changed}; si no se pasa, se calcula desde before/after
        """
        try:
            clean_meta = None
            if meta is not None:
                clean_meta = {k: v for k, v in meta.items() if k not in RESERVED_META}
                clean_meta = _trim_jsonable(_redact(clean_meta))

            _diff = diff
            if _diff is None and (before is not None and after is not None):
                _diff = _compute_diff(before, after)
            _diff = _trim_jsonable(_redact(_diff)) if _diff is not None else None

            request_id, ip, user_agent = _extract_ctx(self.request)

            payload = {
                "operation": operation,
                "module": module,
                "submodule": submodule,
                "feature": feature,
                "object_type": object_type,
                "object_id": object_id,
                "actor_id": actor_id,
                "actor_role": actor_role,
                "before": _trim_jsonable(_redact(before)) if before is not None else None,
                "after": _trim_jsonable(_redact(after)) if after is not None else None,
                "permission_id": permission_id,
                "diff": _diff,
                "request_id": request_id,
                "ip": ip,
                "user_agent": user_agent,
                "meta": clean_meta,
            }

            emit_audit(payload)
        except Exception as e:
            logger.warning("Audit emit failed (%s/%s id=%s): %s", module, operation, object_id, e)

    # Atajos semánticos
    def create(
        self,
        *,
        module: str,
        object_type: str,
        object_id: str,
        after: Dict[str, Any],
        actor_id: Optional[str] = None,
        meta: Optional[Dict[str, Any]] = None,
        submodule: Optional[str] = None,
        feature: Optional[str] = None,
        actor_role: Optional[str] = None,
        permission_id: Optional[str] = None,
    ) -> None:
        # CREATE sin diff (A): before=None, after=estado final
        self.emit(
            operation="CREATE",
            module=module,
            object_type=object_type,
            object_id=object_id,
            actor_id=actor_id,
            actor_role=actor_role,
            before=None,
            after=after,
            permission_id=permission_id,
            meta=meta,
            submodule=submodule,
            feature=feature,
        )

    def update(
        self,
        *,
        module: str,
        object_type: str,
        object_id: str,
        before: Dict[str, Any],
        after: Dict[str, Any],
        actor_id: Optional[str] = None,
        meta: Optional[Dict[str, Any]] = None,
        submodule: Optional[str] = None,
        feature: Optional[str] = None,
        actor_role: Optional[str] = None,
        permission_id: Optional[str] = None,
    ) -> None:
        self.emit(
            operation="UPDATE",
            module=module,
            object_type=object_type,
            object_id=object_id,
            actor_id=actor_id,
            actor_role=actor_role,
            before=before,
            after=after,
            permission_id=permission_id,
            diff=_compute_diff(before or {}, after or {}),
            meta=meta,
            submodule=submodule,
            feature=feature,
        )

    def delete(
        self,
        *,
        module: str,
        object_type: str,
        object_id: str,
        before: Dict[str, Any],
        actor_id: Optional[str] = None,
        meta: Optional[Dict[str, Any]] = None,
        submodule: Optional[str] = None,
        feature: Optional[str] = None,
        actor_role: Optional[str] = None,
        permission_id: Optional[str] = None,
    ) -> None:
        self.emit(
            operation="DELETE",
            module=module,
            object_type=object_type,
            object_id=object_id,
            actor_id=actor_id,
            actor_role=actor_role,
            before=before,
            after=None,
            permission_id=permission_id,
            diff={"removed": before or {}, "changed": {}},
            meta=meta,
            submodule=submodule,
            feature=feature,
        )