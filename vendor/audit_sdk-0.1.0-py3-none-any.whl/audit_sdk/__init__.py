import os, uuid, datetime, requests, logging
from typing import Dict, Any

log = logging.getLogger("audit_sdk")

AUDIT_URL   = os.getenv("AUDIT_URL", "http://localhost:8070/audit-events")
AUDIT_TOKEN = os.getenv("AUDIT_TOKEN", "devtoken")
SERVICE     = os.getenv("SERVICE_NAME", "unknown")
TIMEOUT     = float(os.getenv("AUDIT_HTTP_TIMEOUT", "1.5"))

_session = requests.Session()

def emit_audit(event: Dict[str, Any]) -> None:
    ev = dict(event)
    ev.setdefault("event_id", str(uuid.uuid4()))
    ev.setdefault("ts", datetime.datetime.utcnow().isoformat() + "Z")
    ev.setdefault("service", SERVICE)
    try:
        _session.post(
            AUDIT_URL, json=ev,
            headers={"X-Audit-Token": AUDIT_TOKEN},
            timeout=TIMEOUT,
        )
    except Exception as e:
        log.warning("audit emit failed: %s", e)

# ← Añade esta línea para exportar AuditClient
from .client import AuditClient  # noqa: E402

__all__ = ["emit_audit", "AuditClient"]